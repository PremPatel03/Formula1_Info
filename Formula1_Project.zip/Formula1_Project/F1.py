import json

# Load circuit data from a JSON file
def load_circuits():
    with open('circuits.json') as file:
        return json.load(file)

# Display circuit names for user selection
def display_circuit_names(circuits):
    print("Available circuits:")
    for i, circuit in enumerate(circuits):
        print(f"{i + 1}. {circuit['name']}")

# Display details for a selected circuit
def display_circuit_details(circuit):
    print(f"\nCircuit: {circuit['name']}")
    print(f"Location: {circuit['location']}")
    print(f"Country: {circuit['country']}")
    print(f"Track Length: {circuit['length']} km")
    print(f"Lap Record: {circuit['lap_record']}")
    print("Race Winners:")
    for year, winner in circuit['winners'].items():
        print(f"{year}: {winner}")
    print(f"\nInteresting Facts: {circuit['facts']}")

# Main program loop
def main():
    circuits = load_circuits()
    for circuit in circuits:
        display_circuit_details(circuit)

if __name__ == '__main__':
    main()